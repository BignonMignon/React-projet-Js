/**
 * variable global
 */
var _addition = 0;
set_addition (_addition);
items_name = [];
items_unite_price = [];
items_sub_total = [];
items_qantite = [];
user_name = localStorage.getItem("name");
$(".profil").text("#"+user_name)


function set_addition (addition) {
    $("#total_pay").text(addition.toString() + " Ar");
}

function remove_item(){
    $('.content').children().remove()
}

function add_item_facture(nom_item, prix_item, qte_item, sub_total){
    let component =null;
    if (qte_item == 1) {
        component = `
        <tr>
            <td>${nom_item}</td>
            <td style="text-align: right;padding-right: 10px;">${sub_total} Ar</td>
        </tr>`
    }else{
        component = `
        <tr>
            <td>${nom_item}</td>
            <td style="text-align: right;padding-right: 10px;">*</td>
        </tr>
        <tr>
            <td style="text-align: left; padding-left: 15%;">${qte_item}x ${prix_item}Ar/unité</td>
            <td style="text-align: right;padding-right: 10px;">${sub_total} Ar</td>
        </tr>
        `
    }
    $('.item-facture').append(component);
}


 function add_zero (number) {
     if (number.length ==1) {
         return "0"+number.toString();
       
     }
     return number;
 }
function printDate() {
    let time = new Date();
    let h =  add_zero(time.getHours().toString());
    let mn = add_zero(time.getMinutes().toString());
    let s =  add_zero(time.getSeconds().toString());
    $("#h").text(h.toString());
    $("#mn").text(mn.toString())
    $("#sec").text(s.toString())
}

function loadCategorie(){
    $.get("http://localhost:3000/api/categorie",function(res){
        res.forEach((data)=>{
            let component = ` <li class="item_categorie"> <i class="fa fa-arrow-alt-circle-right"></i> <span>${data.categorie}</span></li>`;
            $(".categorie").append(component);
        })
    })
  
}

function create_seal_card (nom_produit,prix_produit) {
    let component = `
            <div class="box_seal row m-0 mb-3">
                <button class="cancel"><i class="fa fa-times"></i></button>
                <div class="col-6 item_datail">
                    <b>${nom_produit}</b>
                    <p> <span class="price_unit">${prix_produit}</span> ar l'unité</p>
                </div>
                <div class="col-6 item_conntrol">
                    <b><span class="sub_addition">${prix_produit}</span> ar</b>
                    <div class="quantite">
                        <button class="decr"><span class="fa fa-minus"></span></button>
                        <input type="text" class="qte" value="1">
                        <button class="incr"><span class="fa fa-plus"></span></button>
                    </div>
                </div>
            </div>
    `
    $("#main_seal").append(component);
      
}
function create_card_item(nom_produit,prix_produit,code_bar){
    let component = `
                <div class="item col-6 col-md-3 py-2 my-2">
                    <div class="name_item">${nom_produit}</div>
                    <div> <span class="price_item">${prix_produit}</span> ar</div>
                    <div class="code_bar">
                        <img class="barcode" jsbarcode-format="CODE128" jsbarcode-value="${code_bar}" jsbarcode-textmargin="0" jsbarcode-fontoptions="bold" width="150" height="90">
                        </img>
                    </div>
                    <div><img src="../assets/images/Shopping.png" alt="Chariot" srcset=""></div>
                </div>    
    `
    $(".content").append(component)
    JsBarcode(".barcode").init();
}

function control_quantite() {
    value = 0;
    sub_addition = 0;
    //price_item = 0;
    $(".decr").on("click",function () {
        sub_addition =  parseFloat($(this).parents(".item_conntrol").children("b").children(".sub_addition").text())
        value = parseInt($(this).parent().children(".qte").val());
        price_item = parseFloat($(this).parents(".box_seal").children(".item_datail").children("p").children(".price_unit").text())
       if (value >1) {
        value--;
        $(this).parent().children(".qte").val(value);
        if (_addition != 0) {
            _addition -= sub_addition;
            sub_addition =price_item*value;
            _addition += sub_addition;
            $(this).parents(".item_conntrol").children("b").children(".sub_addition").text(sub_addition.toString());
            set_addition(_addition);
        }
       }

    })
    $(".incr").click(function(){
        value = parseInt($(this).parent().children(".qte").val());
        value++;
        sub_addition =  parseFloat($(this).parents(".item_conntrol").children("b").children(".sub_addition").text())
        price_item = parseFloat($(this).parents(".box_seal").children(".item_datail").children("p").children(".price_unit").text());
        value = parseInt($(this).parent().children(".qte").val());
       
        if (_addition != 0) {
             value++;
             $(this).parent().children(".qte").val(value);
            _addition -= sub_addition;
            sub_addition =price_item*value;
            _addition += sub_addition;
            $(this).parents(".item_conntrol").children("b").children(".sub_addition").text(sub_addition.toString());
            set_addition(_addition);
        } 
      

    })
}

setInterval(function(){
    printDate();
},1000)

/**
 * chargement des items via ajax et les traités
 */

load_item = new Promise(async function(resolve,err) {
    var item_data;
    loadCategorie()
    await $.get("http://localhost:3000/api/article",function(res){
        res.forEach((data)=>{
            create_card_item(data.nom_art,data.prix_art,data.code_barre);
            JsBarcode(".barcode").init();
        })
        item_data = res;
        console.log("******");
        
    })
    JsBarcode(".barcode").init();
    resolve(item_data);
   
    // les lignes suivant sont les traitement des evenements achat
  })
  load_item.then(function(item_data){
      console.log("-------");
      
    // recherche produit
    $("#search-bars").change(function(){
        search = $(this).val();
        pattern = new RegExp(search, 'i')
        if (search!="") {
         remove_item()
         item_data.forEach(item_data => {
             if (pattern.test(item_data.nom_art)) {
                create_card_item(item_data.nom_art,item_data.prix_art,item_data.code_barre);
             }            
      });
   
        }
        else{
         remove_item()
         item_data.forEach(item_data => {
            create_card_item(item_data.nom_art,item_data.prix_art,item_data.code_barre);
           
         });
        }
        $(".item").click(function(){
        
            nom_produit = $(this).children(".name_item").text();
            prix_produit = $(this).children("div").children(".price_item").text();
            _addition += parseFloat(prix_produit);
            set_addition(_addition);
            create_seal_card (nom_produit,prix_produit);
             // annuler l' achat d'un item 
             $(".cancel").click(function(){
                  $(this).parent().fadeOut(200, function(){
                     sub_addition =  parseFloat($(this).children(".item_conntrol").children("b").children(".sub_addition").text());
                     _addition = parseFloat(_addition)-sub_addition;
                     set_addition(_addition);
                     $(this).remove()
                  }) 
               
              })
              /**
               * control quantite
               */
            control_quantite();
            console.log("****");
            
            $(".qte").keyup(function(){
               if ($(this).val() <=0 || isNaN($(this).val())) {
                 $(this).val("");
                 $(this).val(1);
                 
               }
               else{
                 value = parseInt($(this).parent().children(".qte").val());
                 value++;
                 sub_addition =  parseFloat($(this).parents(".item_conntrol").children("b").children(".sub_addition").text())
                 price_item = parseFloat($(this).parents(".box_seal").children(".item_datail").children("p").children(".price_unit").text());
                 value = parseInt($(this).parent().children(".qte").val());
                 $(this).parent().children(".qte").val(value);
                 _addition -= sub_addition;
                 sub_addition =price_item*value;
                 _addition += sub_addition;
                 $(this).parents(".item_conntrol").children("b").children(".sub_addition").text(sub_addition.toString());
                 set_addition(_addition);
                 
               }
            })
         })
    })

    // filtre par categorie
    $(".item_categorie").click(async function(){
        filtre = await $(this).children("span").text();
        if(filtre != "All"){
            remove_item();
            item_data.forEach(item_data => {
                if (filtre == item_data.nom_dep) {
                   create_card_item(item_data.nom_art,item_data.prix_art,item_data.code_barre);
                }    
         });
        }else{
            remove_item()
            item_data.forEach(item_data => {
               create_card_item(item_data.nom_art,item_data.prix_art,item_data.code_barre);
            });
        }

        $(".item").click(function(){
        
            nom_produit = $(this).children(".name_item").text();
            prix_produit = $(this).children("div").children(".price_item").text();
            _addition += parseFloat(prix_produit);
            set_addition(_addition);
            create_seal_card (nom_produit,prix_produit);
             // annuler l' achat d'un item 
             $(".cancel").click(function(){
                  $(this).parent().fadeOut(200, function(){
                     sub_addition =  parseFloat($(this).children(".item_conntrol").children("b").children(".sub_addition").text());
                     _addition = parseFloat(_addition)-sub_addition;
                     set_addition(_addition);
                     $(this).remove()
                  }) 
               
              })
              /**
               * control quantite
               */
            control_quantite();
            console.log("****");
            
            $(".qte").keyup(function(){
               if ($(this).val() <=0 || isNaN($(this).val())) {
                 $(this).val("");
                 $(this).val(1);   
               }
               else{
                 value = parseInt($(this).parent().children(".qte").val());
                 value++;
                 sub_addition =  parseFloat($(this).parents(".item_conntrol").children("b").children(".sub_addition").text())
                 price_item = parseFloat($(this).parents(".box_seal").children(".item_datail").children("p").children(".price_unit").text());
                 value = parseInt($(this).parent().children(".qte").val());
                 $(this).parent().children(".qte").val(value);
                 _addition -= sub_addition;
                 sub_addition =price_item*value;
                 _addition += sub_addition;
                 $(this).parents(".item_conntrol").children("b").children(".sub_addition").text(sub_addition.toString());
                 set_addition(_addition);
                 
               }
            })
         })
        
    })
    //fin filtre

    $(".item").click(function(){
        
        nom_produit = $(this).children(".name_item").text();
        prix_produit = $(this).children("div").children(".price_item").text();
        _addition += parseFloat(prix_produit);
        set_addition(_addition);
        create_seal_card (nom_produit,prix_produit);
         // annuler l' achat d'un item 
         $(".cancel").click(function(){
              $(this).parent().fadeOut(200, function(){
                 sub_addition =  parseFloat($(this).children(".item_conntrol").children("b").children(".sub_addition").text());
                 _addition = parseFloat(_addition)-sub_addition;
                 set_addition(_addition);
                 $(this).remove()
              }) 
           
          })
          /**
           * control quantite
           */
        control_quantite();
        console.log("****");
        
        $(".qte").keyup(function(){
           if ($(this).val() <=0 || isNaN($(this).val())) {
             $(this).val("");
             $(this).val(1);
             
           }
           else{
             value = parseInt($(this).parent().children(".qte").val());
             value++;
             sub_addition =  parseFloat($(this).parents(".item_conntrol").children("b").children(".sub_addition").text())
             price_item = parseFloat($(this).parents(".box_seal").children(".item_datail").children("p").children(".price_unit").text());
             value = parseInt($(this).parent().children(".qte").val());
             $(this).parent().children(".qte").val(value);
             _addition -= sub_addition;
             sub_addition =price_item*value;
             _addition += sub_addition;
             $(this).parents(".item_conntrol").children("b").children(".sub_addition").text(sub_addition.toString());
             set_addition(_addition);
             
           }
        })
     })
     $("#btn_payed").click(async function(){
        $('.item-facture').children().remove();
        
       await  $("#main_seal").children().each(function(index){
   
           let name_prod = $(this).children(".item_datail").children("b").text();
           let unit_price_prod = $(this).children(".item_datail").children("p").children(".price_unit").text();
           let sub_addition_prod = $(this).children(".item_conntrol").children("b").children(".sub_addition").text();
           let quantite_prod = $(this).children(".item_conntrol").children(".quantite").children(".qte").val();
            /**
             * ajout des parametres d'achat dans un tableau pour crée la facture
             */
            items_name.push(name_prod);
            items_unite_price.push(unit_price_prod);
            items_sub_total.push(sub_addition_prod);
            items_qantite.push(quantite_prod)
            add_item_facture(name_prod, unit_price_prod, quantite_prod, sub_addition_prod )
        });
        paye =  $("#espece").children("input").val();
        rendu =  $("#rendu").children("input").val();
        let component = `
        <tr style=" border: 1px dashed #424242; border-left: none;border-right: none; height: 30px; font-size: 16px;font-weight: 600;">
            <td>TOTAL</td>
            <td style="text-align: right;padding-right: 10px">${_addition} Ar</td>
        </tr> 
        `
        let detail = `
        <tr >
            <td>Espece : ${paye} Ar</td>
        </tr> 
        <tr >
            <td>Rendu : ${rendu} Ar</td>
        </tr> 
        `
       
        $('.item-facture').append(component);
        $('.item-facture').append(detail);
        paye =  $("#espece").children("input").val();
        rendu =  $("#rendu").children("input").val();
        $.get(`http://localhost:3000/api/facture/${_addition}/${paye}/${rendu}`,function(res){
                console.log(res.insertId);
                let component = `
                <img class="barcode" jsbarcode-format="CODE128"     jsbarcode-value="${res.insertId}" jsbarcode-textmargin="0" jsbarcode-fontoptions="bold" width="120" height="60">
                </img>`
                $(".id_facture").append(component)
                JsBarcode(".barcode").init();
        }
        );
        $("#new_seal").click(function(){
            window.location.href="http://127.0.0.1:5500/front_office/pages/pos.html";
        })
    })
    $("#input_espece").keyup(async function(){
        value =  $(this).val();

        if (isNaN(value)) {
            $(this).val(0)
            $("#rendu").children("input").val(0);
        }
       
    })
    $("#espece").focusout(function(){
        value =  $(this).children("input").val();
       if(value != 0){
          rendu = value - _addition;
          $("#rendu").children("input").val(rendu);
       }
     
    })
  })



