
$(document).ready(async function (){
    $("#info").hide();
    $("form").submit(function(event){
        console.log("test");
        event.preventDefault()
        LoadUser = new Promise(async function(resolve,reject){
            let email_ = document.forms["form"]["email"].value ;
            let password_ = document.forms["form"]["password"].value;
            let data = {
                email:email_,
                password:password_
            }
            console.log("email :" + email_);
            console.log("email :" + password_);
            await $.get(`http://localhost:3000/api/user/${email_}/${password_}`,
            function(res){
                console.log(res);
                console.log("*******");
                resolve(res)        
            })  
           ;
        })
        LoadUser.then(function(user){
            data = user;
            console.log(data);
            if (1==1) {
                if (data[0].id==null) {
                    $("#info").show("fast")
                }
                else{
                    console.log("it work");
                    localStorage.clear()
                    localStorage.setItem("name",data[0].name);
                    $("body").addClass("dispose");
                            setTimeout(()=>{
                            window.location.href="http://127.0.0.1:5500/front_office/pages/pos.html";
                            },2000)    
                }
            
            }
        })     
     })
});