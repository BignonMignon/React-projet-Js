const CONFIG = {
    VERSION:1,
    BUILD:1,
    URL:'http://localhost',
    API_PATH:'/api',
    PORT:process.env.PORT || 3000,
    DB:{
        HOST:'localhost',
        USER :'root',
        PASSWORD:'',
        DATABASE:'db_score'
    },
    //url de la connection de la base de donne
    get_db_connection:function (){
        let params_connection = {
            host:this.DB.HOST,
            user:this.DB.USER,
            password:this.DB.PASSWORD,
            database:this.DB.DATABASE
        }
        return params_connection;
    },
    //url de la connection de l'application
    get_http_url: function(){
        return 'http://' + this.URL + ":" + this.PORT;
        }
}

module.exports = CONFIG;