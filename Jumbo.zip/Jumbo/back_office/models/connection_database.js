var mysql = require('mysql')
const CONFIG = require('../config')

const EXECUTE = mysql.createConnection(CONFIG.get_db_connection());
EXECUTE.connect((error)=>{
    if (error) {
        console.log(error);
    }
    else{
        console.log("coonnection avec succés");
    }
    
})

module.exports = EXECUTE;