var mysql_connect = require("../models/connection_database")

const ARTICLE_CONTROLEUR = {
    GET_:function(req,res){
       mysql_connect.query("SELECT * FROM articles order by nom_dep",(err,rows,fields)=>{
           if (!err) {
               res.json(rows);
           }
       })
    },
    POST_:function(req,res){
        res.send("It work for user POST")
        return;
    }
}

module.exports = ARTICLE_CONTROLEUR;