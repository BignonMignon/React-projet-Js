var mysql_connect = require("../models/connection_database")

const USER_CONTROLEUR = {

    GET_:function(req,res){
        email = req.params.email;   
        password = req.params.password;
        mysql_connect.query("SELECT * FROM users WHERE email = ? and password = ?",[email,password],(err,rows,fields)=>{
            if (!err) {
                res.json(rows);
            }
            else{
                res.send("une erreur c'est produit")
            }
        })
        return;
    }
}

module.exports = USER_CONTROLEUR;