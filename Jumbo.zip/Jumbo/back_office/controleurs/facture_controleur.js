var mysql_connect = require("../models/connection_database")
const FACTURE_CONTROLEUR = {

    GET_:function(req,res){
        montant = req.params.montant;
        paye = req.params.paye;
        rendu = req.params.rendu
        mysql_connect.query("INSERT INTO factures(montant,paye,rendu) VALUES(?,?,?)",[montant,paye,rendu],(err,rows,fields)=>{
            if (!err) {
                res.send(rows);
            }
            else{
                res.send("une erreur c'est produit")
            }
        })
        return;
    }
}

module.exports = FACTURE_CONTROLEUR;