var mysql_connect = require("../models/connection_database")

const CATEGORIE_CONTROLEUR = {
    GET_:function(req,res){
       mysql_connect.query("SELECT nom_dep as categorie FROM departements order by nom_dep",(err,rows,fields)=>{
           if (!err) {
               res.json(rows);
           }
       })
    },
    POST_:function(req,res){
        res.send("It work for user POST")
        return;
    }
}

module.exports = CATEGORIE_CONTROLEUR;