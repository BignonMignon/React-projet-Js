/**
 * api du article
 * @autor Mamisoa  Rakotondramanana
 */
var express = require('express');
const ARTICLE_CONTROLEUR = require('../controleurs/article_controleur')
const ROUTER = express.Router();


// route pour user
const ARTICLES_ROUTES = (APP)=>{
    ROUTER.route('/article')
        .get(ARTICLE_CONTROLEUR.GET_)
    return ROUTER;
}

module.exports = ARTICLES_ROUTES;