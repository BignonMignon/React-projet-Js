/**
 * api du categorie
 * @autor Mamisoa  Rakotondramanana
 */
 var express = require('express');
 const CATEGORIE_CONTROLEUR = require('../controleurs/categorie_controleur')
 const ROUTER = express.Router();
 
 
 // route pour user
 const CATEGORIES_ROUTES = (APP)=>{
     ROUTER.route('/categorie')
         .get(CATEGORIE_CONTROLEUR.GET_)
     return ROUTER;
 }
 
 module.exports = CATEGORIES_ROUTES;