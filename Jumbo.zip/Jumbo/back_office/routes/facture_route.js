/**
 * api facture
 * @autor Houby Razafinantoanina
 */
 var express = require('express');
 const FACTURE_CONTROLEUR = require('../controleurs/facture_controleur')
 const ROUTER = express.Router();
 
 
 // route pour user
 const FACTURES_ROUTES = (APP)=>{
     ROUTER.route('/facture/:montant/:paye/:rendu')
         .get(FACTURE_CONTROLEUR.GET_)
     return ROUTER;
 }
 
 module.exports = FACTURES_ROUTES;