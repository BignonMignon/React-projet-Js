/**
 * api user
 * @autor Mamisoa  Rakotondramanana
 */
 var express = require('express');
 const USER_CONTROLEUR = require('../controleurs/user_controleur')
 const ROUTER = express.Router();
 
 
 // route pour user
 const USERS_ROUTES = (APP)=>{
     ROUTER.route('/user/:email/:password')
         .get(USER_CONTROLEUR.GET_)
     return ROUTER;
 }
 
 module.exports = USERS_ROUTES;