/**
 * server js
 * @author Houby Razafinantoanina
 */

// importation librairies
var express = require('express'),
    cors = require('cors'),
    body = require("body-parser");



//importation module de l'application 
const CONFIG = require('./config');
const ARTICLES_ROUTES = require('./routes/article_route');
const CATEGORIES_ROUTES = require('./routes/categorie_route');
const USERS_ROUTES = require('./routes/user_route');
const FACTURES_ROUTES = require('./routes/facture_route');


// configuration des routes
const APP = new express();
APP.use(body.json());
APP.use(cors({origin: '*'}))
APP.use(CONFIG.API_PATH,ARTICLES_ROUTES());
APP.use(CONFIG.API_PATH,CATEGORIES_ROUTES())
APP.use(CONFIG.API_PATH,USERS_ROUTES())
APP.use(CONFIG.API_PATH,FACTURES_ROUTES())

/**
 * RUN SERVER 
 */
APP.listen(CONFIG.PORT);
console.log("server lancé sur le port :"+CONFIG.PORT);


